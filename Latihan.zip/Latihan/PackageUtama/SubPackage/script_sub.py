def cetak_sub() :
    print("ini Script sub dari subPackage")