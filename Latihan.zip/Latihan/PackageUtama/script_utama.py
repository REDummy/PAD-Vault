def cetak_utama():
    print("ini di script utama")