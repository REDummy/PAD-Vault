from PackageUtama.script_utama import cetak_utama
from PackageUtama.SubPackage.script_sub import cetak_sub

cetak_utama()
cetak_sub()